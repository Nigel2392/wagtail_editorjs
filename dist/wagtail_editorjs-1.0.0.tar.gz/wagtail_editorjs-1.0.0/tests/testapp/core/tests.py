from django.test import TestCase
from django.conf import settings
from os import path


FIXTURES = path.join(settings.BASE_DIR, "core/fixtures")
