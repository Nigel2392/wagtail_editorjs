REGISTER_HOOK_NAME = "register_wagtail_editorjs_features"
BUILD_CONFIG_HOOK = "editorjs_widget_build_config"
