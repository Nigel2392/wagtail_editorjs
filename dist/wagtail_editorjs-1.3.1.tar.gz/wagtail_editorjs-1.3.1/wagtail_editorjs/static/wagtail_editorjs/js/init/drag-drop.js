window.registerInitializer((widget) => {
    new window.DragDrop(widget.editor);
});